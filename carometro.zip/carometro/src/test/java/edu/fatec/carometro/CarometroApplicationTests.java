package edu.fatec.carometro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarometroApplicationTests {

	@Test
	void contextLoads() {
	}

}
